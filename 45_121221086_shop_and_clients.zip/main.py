from models.MarketSimulationModel import MarketSimulationModel

if __name__ == "__main__":
    # Parameters for the simulation
    GRID_WIDTH = 10
    GRID_HEIGHT = 10
    NUM_CLIENTS = 10
    NUM_SHOPS = 3

    # Initialize the model
    model = MarketSimulationModel(
        width=GRID_WIDTH,
        height=GRID_HEIGHT,
        num_clients=NUM_CLIENTS,
        num_shops=NUM_SHOPS
    )

    # Run the simulation for 10 days
    NUM_DAYS = 50
    for day in range(NUM_DAYS):
        print(f"\n--- Simulating Day {day + 1} ---")
        model.step()
        print(f"--- End of Day {day + 1} ---\n")

