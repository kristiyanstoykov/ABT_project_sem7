from mesa import Model
from mesa.time import RandomActivation
from mesa.space import MultiGrid
from agents.ClientAgent import ClientAgent
from agents.ShopAgent import ShopAgent
from .Product import Product
from .Opinion import Opinion

class MarketSimulationModel(Model):
    def __init__(self, width, height, num_clients, num_shops):
        super().__init__()
        self.grid = MultiGrid(width, height, torus=True)  # A grid for agent positioning
        self.schedule = RandomActivation(self)
        self.day_count = 0

        # Create shops
        self.shops = []
        for i in range(num_shops):
            shop = ShopAgent(unique_id=i, model=self)
            shop.add_product(Product(product_id=1, name="Milk", quality=8, price=2.5, quantity=50))
            shop.add_product(Product(product_id=2, name="Eggs", quality=7, price=3.0, quantity=30))
            self.shops.append(shop)
            empty_cells = [(x, y) for (x, y) in self.grid.empties]  # Get all empty cells
            if empty_cells:
                random_position = self.random.choice(empty_cells)  # Choose a random empty cell
                self.grid.place_agent(shop, random_position)
            else:
                raise RuntimeError("No empty cells available for placing the agent.")

        # Create clients
        self.clients = []
        for i in range(num_clients):
            client = ClientAgent(
                unique_id=i + num_shops,
                model=self,
                money=50,
                product_to_sell="Cookies",
                product_needs=[
                    Product(product_id=1, name="Milk", quality=0, price=0, quantity=5),
                    Product(product_id=2, name="Eggs", quality=0, price=0, quantity=3)
                ]
            )
            self.clients.append(client)
            self.schedule.add(client)
            empty_cells = [(x, y) for (x, y) in self.grid.empties]
            if empty_cells:
                random_position = self.random.choice(empty_cells)
                self.grid.place_agent(client, random_position)
            else:
                raise RuntimeError("No empty cells available for placing the agent.")

        # Initialize client opinions about all shops
        for client in self.clients:
            for shop in self.shops:
                # Initialize opinions with neutral scores
                client.opinions[shop.unique_id] = Opinion(shop_id=shop.unique_id, initial_score=0.0)

    def step(self):
        print(f"\n--- Day {self.day_count + 1} ---")

        # Replenish client needs at the start of each day
        for agent in self.schedule.agents:
            if isinstance(agent, ClientAgent):
                agent.replenish_needs()

        self.log_daily_statistics()
        print(f"\n--- --- --- --- --- --- --- --- --- --- --- ---\n")
        self.schedule.step()
        self.log_daily_statistics()
        self.day_count += 1

        for shop in self.shops:
            shop.restock_products()
            shop.adjust_prices()

    def log_daily_statistics(self):
        print(f"\n--- Day {self.day_count + 1} ---")
        print("\nShop Statistics:")
        for shop in self.shops:
            total_stock = sum(p.quantity for p in shop.products)
            print(f"Shop {shop.unique_id}: Money = {shop.money:.2f}, Total Stock = {total_stock}")
            for product in shop.products:
                print(f"  {product}")

        print("\nClient Statistics:")
        for agent in self.schedule.agents:
            if isinstance(agent, ClientAgent):
                inventory_summary = ", ".join(
                    f"{p.name}: {p.quantity}" for p in agent.inventory
                ) or "Empty"
                print(f"Client {agent.unique_id}: Money = {agent.money:.2f}, Inventory = {inventory_summary}")
