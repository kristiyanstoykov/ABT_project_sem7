from mesa import Agent
from models.Product import Product
from models.Opinion import Opinion


class ClientAgent(Agent):
    def __init__(self, unique_id, model, money, product_to_sell, product_needs):
        super().__init__(unique_id, model)
        self.money = money
        self.product_to_sell = product_to_sell
        self.product_needs = product_needs  # List of Product instances with id, name, and quantity
        self.inventory = []  # List of Product instances the client owns
        self.opinions = {}  # Dict of shop_id -> Opinion instances

    def choose_best_shop(self):
        if not self.opinions:
            print(f"Client {self.unique_id}: No opinions yet.")
            return None

        # Find the best shop
        best_shop = max(self.opinions.values(), key=lambda opinion: opinion.get_score())
        if best_shop.get_score() == 0:
            print(f"Client {self.unique_id}: All opinions are neutral, choosing a random shop.")
            return self.random.choice(list(self.opinions.keys()))
        print(f"Client {self.unique_id}: Best shop is {best_shop.shop_id} with score {best_shop.get_score()}")
        return best_shop.shop_id

    def replenish_needs(self):
        for need in self.product_needs:
            # Reset quantities to original daily requirements
            if need.product_id == 1:  # Milk
                need.quantity = 5
            elif need.product_id == 2:  # Eggs
                need.quantity = 3

    def buy_products(self, shop):
        for need in self.product_needs:
            if need.quantity <= 0:
                continue

            # Check if the shop has the required product
            available_product = next((p for p in shop.products if p.product_id == need.product_id), None)
            if not available_product:
                print(f"Client {self.unique_id}: Product {need.name} not found in Shop {shop.unique_id}")
                continue

            if available_product.quantity <= 0:
                print(f"Client {self.unique_id}: Product {need.name} out of stock in Shop {shop.unique_id}")
                continue

            # Determine quantity to purchase
            purchase_quantity = min(need.quantity, available_product.quantity)
            cost = purchase_quantity * available_product.price

            if self.money >= cost:
                # Log the purchase
                print(f"Client {self.unique_id}: Buying {purchase_quantity} of {need.name} for {cost:.2f} from Shop {shop.unique_id}")

                # Complete the purchase
                self.money -= cost
                shop.money += cost
                need.quantity -= purchase_quantity
                available_product.adjust_quantity(-purchase_quantity)

                # Add to inventory
                inventory_product = next((p for p in self.inventory if p.product_id == need.product_id), None)
                if inventory_product:
                    inventory_product.adjust_quantity(purchase_quantity)
                else:
                    self.inventory.append(
                        Product(
                            product_id=available_product.product_id,
                            name=available_product.name,
                            quality=available_product.quality,
                            price=available_product.price,
                            quantity=purchase_quantity
                        )
                    )

                self.update_opinion(shop.unique_id, experience=2, reason="Successful purchase.")
            else:
                print(f"Client {self.unique_id}: Not enough money to buy {need.name} from Shop {shop.unique_id}")
                self.update_opinion(shop.unique_id, experience=-1, reason="Insufficient funds.")



    def produce_product(self):
        # Ensure all required ingredients are available
        if all(
            any(item.product_id == need.product_id and item.quantity >= need.quantity for item in self.inventory)
            for need in self.product_needs
        ):
            # Deduct ingredients from inventory
            for need in self.product_needs:
                for item in self.inventory:
                    if item.product_id == need.product_id:
                        item.adjust_quantity(-need.quantity)
                        break

            self.money += 20  # Example profit
        else:
            pass  # Not enough ingredients

    def update_opinion(self, shop_id, experience, reason):
        if shop_id not in self.opinions:
            self.opinions[shop_id] = Opinion(shop_id=shop_id, initial_score=0.0)
        self.opinions[shop_id].adjust_score(change=experience, reason=reason)

    def share_opinion(self, other_client):
        for shop_id, opinion in self.opinions.items():
            if shop_id not in other_client.opinions:
                other_client.opinions[shop_id] = Opinion(shop_id=shop_id, initial_score=0.0)
            if other_client.opinions[shop_id].get_score() < opinion.get_score():
                print(f"Client {self.unique_id} sharing opinion about Shop {shop_id} with Client {other_client.unique_id}")
                other_client.opinions[shop_id].adjust_score(
                    change=0.5, reason="Opinion shared by another client."
                )

    def step(self):
        print(f"Client {self.unique_id}: Starting daily step.")

        # Choose a shop and attempt to buy products
        best_shop_id = self.choose_best_shop()
        if best_shop_id is not None:
            best_shop = next((shop for shop in self.model.shops if shop.unique_id == best_shop_id), None)
            if best_shop:
                self.buy_products(best_shop)

        self.produce_product()

        # Share opinions with nearby clients
        neighbors = self.model.grid.get_neighbors(self.pos, moore=True, include_center=False)
        for neighbor in neighbors:
            if isinstance(neighbor, ClientAgent):
                print(f"Client {self.unique_id} sharing opinions with Client {neighbor.unique_id}")
                self.share_opinion(neighbor)

        print(f"Client {self.unique_id}: Ending daily step.")


